"""Third page of the web app: sample map coloured by Piper field (the code is in ../map_app.py)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import map_app  # noqa: E402

map_app.run_streamlit()
