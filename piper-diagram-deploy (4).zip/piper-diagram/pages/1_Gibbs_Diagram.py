"""Second page of the web app: the Gibbs diagram (the code is in ../gibbs_app.py)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import gibbs_app  # noqa: E402

gibbs_app.run_streamlit()
